 <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">UFT<sup>M-E-S</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="#">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>UFT SERVICES</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
          menu
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <router-link class="nav-link collapsed" to="/FundsAndPayments" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>FundsAndPayments</span>
        </router-link>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">FundsMenu:</h6>
            <a class="collapse-item" href="">Add Donor</a>
            <a class="collapse-item" href="">Add Donation</a>
            <a class="collapse-item" href="">Make Payments</a>
            <a class="collapse-item" href="">ViewPayments</a>
            <a class="collapse-item" href="">View Donations</a>
            <a class="collapse-item" href="">View Donors</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-wrench"></i>
          <span>Enrollments</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Registrations:</h6>
            <a class="collapse-item" href="utilities-color.html">RegisterAgent</a>
            <a class="collapse-item" href="utilities-border.html">AssignAgent</a>
            <a class="collapse-item" href="utilities-animation.html">ViewMembers</a>
            <a class="collapse-item" href="utilities-other.html">AssignHeads</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Addons
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-folder"></i>
          <span>Validations</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">RecordManagement:</h6>
            <a class="collapse-item" href="<?php echo e(url('/admin/login')); ?>">UpdateMembers</a>
            <a class="collapse-item" href="<?php echo e(route('register')); ?>">AddUser</a>
            <div class="collapse-divider"></div>
        </div>
      </li>

      <!-- Nav Item - Charts -->
          <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseVisuals" aria-expanded="true" aria-controls="collapseVisuals">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Visualisations</span>
        </a>
        <div id="collapseVisuals" class="collapse" aria-labelledby="headingVisuals" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Graphs:</h6>
            <a class="collapse-item" href="buttons.html">MonthlyDonations</a>
            <a class="collapse-item" href="cards.html">ChangeInEnrollments</a>
            <a class="collapse-item" href="buttons.html">ChangesInFundings</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <router-link class="nav-link" to="/Promotions">
          <i class="fas fa-fw fa-table"></i>
          <span>Promotions</span>
        </router-link>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
   