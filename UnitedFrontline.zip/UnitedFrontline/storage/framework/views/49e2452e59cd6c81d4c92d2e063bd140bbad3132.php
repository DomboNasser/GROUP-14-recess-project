<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>UnitedFronlineTransformation</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 45px;
                color: blue;
            }

            .links > a {
                color: blue;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">UFTuganda</div>
                
            <div><img src="/logos/front.jpg" height="300" width="200" class="rounded-circle"></div>
            <div class="title m-b-md">Welcome To</div>
            <div class="title m-b-md">United Front For Transformation Party</div>
            <div><strong>unitedfrontlinetransformation.org</strong></div>
                          <div>
                            <strong>153</strong>posts
                            <strong>23k</strong>followers
                            <strong>212</strong>following
                        </div>
                        <div>United Frontline in a new and registered political party in uganda.</div>
                        <div>We are global community of millions of people promoting peace, prosperity, togetheriness and democracy in uganda</div>
                        <div>Join us today we build uganda for a better tommorrow</div>  
                        <div><a href="#"><strong>www.unitedfronline.ac.ug</strong></a></div>              
            </div>
        </div>
    </body>
</html>
