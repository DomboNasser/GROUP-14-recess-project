@extends('layouts.app')

<link rel="stylesheet" type="text/css" href="style.css">
<style type="text/css">
        .header {
            background: #003366;
        }
        button[name=uft] {
            background: #003366;
        }
    li {padding:20px;margin-top:10px;list-style-type:none;border-bottom: 1px solid Magenta;font-size:15px;display:inline;list-style:none;}
        
            * {color:Teal;}
            h1 {color:white; background-color:DarkCyan;padding:40px;border-radius:40px;font-family:Algerian;}
            h2 {color:white;}
            a {color:white;text-decoration:none;}
            #adv {background-color:DarkCyan;font-family:Candara;font-size:40px;color:white;padding:40px;}
            input {background-color:Beige;color:blue;}
            table {border-style:solid;border-width:thin;margin-top:0px;background-color:MintCream;border-color:DarkCyan}
            button{color:white; background-color:DarkCyan;padding:40px;border-radius:40px;height: 50px; width: 200px;}
            li:hover {font-size:20px;}  
        </style>    

@section('content')

                <div class="header">REGISTER NEW USERS</div>

        
                    <center><form class="form-horizontal" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}
                                 <div class="input-group">
                        {{ $errors->has('name') ? ' has-error' : '' }}
                            <label for="name">Name</label>
                <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                            {{ $errors->first('name') }}
                                    
                                @endif
                                </div>
                                 <div class="input-group">
                        {{ $errors->has('email') ? ' has-error' : '' }}
                            <label for="email">Email</label>
        <input id="email" type="email" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                        {{ $errors->first('email') }}
                                @endif
                                </div>
                                 <div class="input-group">
                         {{ $errors->has('username') ? ' has-error' : '' }}
                            <label for="username">Username</label>
 <input id="username" type="text" name="username" value="{{ old('username') }}" required>

                                @if ($errors->has('email'))
                        {{ $errors->first('username') }}
                                @endif
                            </div>
                             <div class="input-group">
               {{ $errors->has('role') ? ' has-error' : '' }}
                            <label for="role">Role</label>
         <input id="role" type="text" name="role" value="{{ old('role') }}" required>

                                @if ($errors->has('role'))
                                {{ $errors->first('role') }}
                                @endif
                            </div>
                             <div class="input-group">
                {{ $errors->has('password') ? ' has-error' : '' }}
                        <label for="password">Password</label>
                <input id="password" type="password" name="password" required>

                                @if ($errors->has('password'))
                        {{ $errors->first('password') }}
                                @endif
                            </div>
                             <div class="input-group">
             <label for="password-confirm" >Confirm Password</label>
     <input id="password-confirm" type="password" name="password_confirmation" required>
                              </div>
                               <div class="input-group">
        <button type="submit" class="btn" name="uft"> +Register</button>
                           </div>
                       </form></center>
@endsection
