    
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

import VueRouter from 'vue-router'
Vue.use(VueRouter)


let routes = [

      {path: '/Funds&Payments',component:Foo},  
      {path: '/Enrollments',component:Bar},
      {path: '/Validations',component:Bar},
      {path: '/Visualisations',component:Bar},
      {path: '/Promotions',component: require('./components/Promotions.vue'}

]
 
const router = new VueRouter({
routes

})

Vue.component('example-component', require('./components/ExampleComponent.vue'));

const app = new Vue({
    el: '#app',
    router
});
